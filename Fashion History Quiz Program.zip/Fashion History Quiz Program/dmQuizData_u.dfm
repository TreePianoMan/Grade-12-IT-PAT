object dmQuizData: TdmQuizData
  OnCreate = DataModuleCreate
  Height = 480
  Width = 640
  object conQuizData: TADOConnection
    ConnectionString = 
      'Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=H:\Gr' +
      'ade 12 PAT\Fashion History Quiz Program (1)\Fashion History Quiz' +
      ' Program\QuizData.mdb;Mode=ReadWrite;Persist Security Info=False' +
      ';Jet OLEDB:System database="";Jet OLEDB:Registry Path="";Jet OLE' +
      'DB:Database Password="";Jet OLEDB:Engine Type=5;Jet OLEDB:Databa' +
      'se Locking Mode=1;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:' +
      'Global Bulk Transactions=1;Jet OLEDB:New Database Password="";Je' +
      't OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=' +
      'False;Jet OLEDB:Don'#39't Copy Locale on Compact=False;Jet OLEDB:Com' +
      'pact Without Replica Repair=False;Jet OLEDB:SFP=False'
    LoginPrompt = False
    Provider = 'Microsoft.Jet.OLEDB.4.0'
    Left = 136
    Top = 200
  end
  object qrySQL: TADOQuery
    Connection = conQuizData
    CursorType = ctStatic
    Parameters = <>
    SQL.Strings = (
      'SELECT * FROM tblUsers')
    Left = 296
    Top = 200
  end
  object dsrQuizData: TDataSource
    DataSet = qrySQL
    Left = 432
    Top = 200
  end
end
