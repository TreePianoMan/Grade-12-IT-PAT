object frmHistory_of_Fashion_Quiz: TfrmHistory_of_Fashion_Quiz
  Left = 304
  Top = 103
  Caption = 'History of Fashion Quiz'
  ClientHeight = 472
  ClientWidth = 766
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poDesigned
  OnActivate = FormActivate
  OnCreate = FormCreate
  TextHeight = 15
  object PageControl: TPageControl
    Left = 0
    Top = 0
    Width = 761
    Height = 473
    ActivePage = tabFacts
    TabOrder = 0
    object tabLogin: TTabSheet
      Caption = 'Login'
      object pnlLogin: TPanel
        Left = 0
        Top = -1
        Width = 750
        Height = 441
        Color = clDarksalmon
        ParentBackground = False
        TabOrder = 0
        object lblLoginHeading: TLabel
          Left = 208
          Top = 24
          Width = 338
          Height = 46
          Caption = 'Fashion History'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -37
          Font.Name = 'Showcard Gothic'
          Font.Style = [fsBold]
          ParentFont = False
        end
        object lblLogin: TLabel
          Left = 360
          Top = 84
          Width = 32
          Height = 17
          Caption = 'Login'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Segoe UI'
          Font.Style = [fsUnderline]
          ParentFont = False
        end
        object lblLoginDescription: TLabel
          Left = 256
          Top = 107
          Width = 236
          Height = 15
          Alignment = taCenter
          Caption = 'Please enter your username and password.'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
        end
        object lblLoginPassword: TLabel
          Left = 280
          Top = 219
          Width = 50
          Height = 15
          Caption = 'Password'
        end
        object lblLoginUsername: TLabel
          Left = 280
          Top = 153
          Width = 53
          Height = 15
          Caption = 'Username'
        end
        object lblLoginSignUpOption: TLabel
          Left = 312
          Top = 352
          Width = 129
          Height = 15
          Cursor = crHandPoint
          Caption = 'Don'#39't have an account?'
          Color = clDarksalmon
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold, fsUnderline]
          ParentColor = False
          ParentFont = False
          Transparent = False
          OnClick = lblLoginSignUpOptionClick
          OnMouseEnter = lblLoginSignUpOptionMouseEnter
          OnMouseLeave = lblLoginSignUpOptionMouseLeave
        end
        object edtLoginUsername: TEdit
          Left = 280
          Top = 174
          Width = 193
          Height = 23
          TabOrder = 0
        end
        object edtLoginPassword: TEdit
          Left = 280
          Top = 240
          Width = 193
          Height = 23
          TabOrder = 1
        end
        object btnLogin: TButton
          Left = 336
          Top = 281
          Width = 81
          Height = 32
          Caption = 'Login'
          TabOrder = 2
          OnClick = btnLoginClick
        end
        object cbxHidePassword: TCheckBox
          Left = 479
          Top = 243
          Width = 97
          Height = 17
          Caption = 'Hide Password'
          TabOrder = 3
          OnClick = cbxHidePasswordClick
        end
      end
      object pnlSignup: TPanel
        Left = -547
        Top = -285
        Width = 749
        Height = 441
        Color = clDarksalmon
        ParentBackground = False
        TabOrder = 1
        object lblSignupHeading: TLabel
          Left = 208
          Top = 24
          Width = 338
          Height = 46
          Caption = 'Fashion History'
          Font.Charset = ANSI_CHARSET
          Font.Color = clBlack
          Font.Height = -37
          Font.Name = 'Showcard Gothic'
          Font.Style = [fsBold]
          ParentFont = False
        end
        object lblSignup: TLabel
          Left = 356
          Top = 84
          Width = 45
          Height = 17
          Caption = 'Sign-up'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clBlack
          Font.Height = -13
          Font.Name = 'Segoe UI'
          Font.Style = [fsUnderline]
          ParentFont = False
        end
        object lblSignupDescription: TLabel
          Left = 256
          Top = 107
          Width = 246
          Height = 15
          Alignment = taCenter
          Caption = 'Please enter a valid username and password.'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clBlack
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
        end
        object lblSignupPassword: TLabel
          Left = 280
          Top = 219
          Width = 141
          Height = 15
          Caption = 'Password (8-20 characters)'
        end
        object lblSignupUsername: TLabel
          Left = 280
          Top = 153
          Width = 141
          Height = 15
          Caption = 'Username (3-20characters)'
        end
        object edtSignupUsername: TEdit
          Left = 280
          Top = 174
          Width = 193
          Height = 23
          TabOrder = 0
        end
        object edtSignupPassword: TEdit
          Left = 280
          Top = 240
          Width = 193
          Height = 23
          TabOrder = 1
        end
        object btnSignup: TButton
          Left = 328
          Top = 305
          Width = 105
          Height = 48
          Caption = 'Sign-up'
          TabOrder = 2
          OnClick = btnSignupClick
        end
        object btnSignupBack: TButton
          Left = 24
          Top = 24
          Width = 57
          Height = 33
          Caption = 'Back'
          TabOrder = 3
          OnClick = btnSignupBackClick
        end
      end
    end
    object tabHome: TTabSheet
      Caption = 'Homepage'
      ImageIndex = 1
      object pnlHomepage: TPanel
        Left = 0
        Top = 0
        Width = 765
        Height = 470
        Color = clLightsalmon
        ParentBackground = False
        TabOrder = 0
        object lblHomepageHeading: TLabel
          Left = 112
          Top = 32
          Width = 555
          Height = 46
          Caption = 'Fashion History Homepage'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -37
          Font.Name = 'Showcard Gothic'
          Font.Style = [fsBold]
          ParentFont = False
        end
        object lblWelcomeUserBlack: TLabel
          Left = 280
          Top = 84
          Width = 225
          Height = 33
          Caption = 'Welcome '#39'user'#39'!'
          Font.Charset = ANSI_CHARSET
          Font.Color = clBlack
          Font.Height = -27
          Font.Name = 'Showcard Gothic'
          Font.Style = []
          ParentFont = False
        end
        object lblWelcomeUserWhite: TLabel
          Left = 283
          Top = 81
          Width = 225
          Height = 33
          Caption = 'Welcome '#39'user'#39'!'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWhite
          Font.Height = -27
          Font.Name = 'Showcard Gothic'
          Font.Style = []
          ParentFont = False
        end
        object lblFashionHistoryHeadingWhite: TLabel
          Left = 115
          Top = 29
          Width = 555
          Height = 46
          Caption = 'Fashion History Homepage'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWhite
          Font.Height = -37
          Font.Name = 'Showcard Gothic'
          Font.Style = [fsBold]
          ParentFont = False
        end
        object btnHomepageFacts: TButton
          Left = 112
          Top = 168
          Width = 153
          Height = 113
          Caption = 'View Facts'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Segoe Script'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 0
          OnClick = btnHomepageFactsClick
        end
        object btnHomepageMainQuiz: TButton
          Left = 312
          Top = 168
          Width = 153
          Height = 113
          Caption = 'Main Quiz'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Segoe Script'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 1
          OnClick = btnHomepageMainQuizClick
        end
        object btnHomepageEraQuiz: TButton
          Left = 514
          Top = 168
          Width = 153
          Height = 113
          Caption = 'Era Quiz'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -16
          Font.Name = 'Segoe Script'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 2
          OnClick = btnHomepageEraQuizClick
        end
        object btnHomepageAdminTools: TButton
          Left = 320
          Top = 328
          Width = 137
          Height = 57
          Caption = 'Admin Tools'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -15
          Font.Name = 'Segoe Script'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 3
          OnClick = btnHomepageAdminToolsClick
        end
      end
    end
    object tabFacts: TTabSheet
      Caption = 'Facts'
      ImageIndex = 2
      object pnlFactsBackground: TPanel
        Left = 3
        Top = 3
        Width = 765
        Height = 470
        Color = clBurlywood
        ParentBackground = False
        TabOrder = 0
        object pnlFactsPickEra: TPanel
          Left = 10
          Top = 13
          Width = 369
          Height = 401
          Color = clAntiquewhite
          ParentBackground = False
          TabOrder = 0
          object lblFactsPickEra: TLabel
            Left = 16
            Top = 16
            Width = 344
            Height = 21
            Caption = 'Please pick which era you would like to view the facts of.'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object btnFacts1920s: TButton
            Left = 32
            Top = 64
            Width = 129
            Height = 73
            Caption = '1920s'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Script'
            Font.Style = []
            ParentFont = False
            TabOrder = 0
            OnClick = btnFacts1920sClick
          end
          object btnFacts1950s: TButton
            Left = 208
            Top = 64
            Width = 129
            Height = 73
            Caption = '1950s'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Script'
            Font.Style = []
            ParentFont = False
            TabOrder = 1
            OnClick = btnFacts1950sClick
          end
          object btnFacts1970s: TButton
            Left = 32
            Top = 165
            Width = 129
            Height = 73
            Caption = '1970s'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Script'
            Font.Style = []
            ParentFont = False
            TabOrder = 2
            OnClick = btnFacts1970sClick
          end
          object btnFacts1990s: TButton
            Left = 208
            Top = 165
            Width = 129
            Height = 73
            Caption = '1990s'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Script'
            Font.Style = []
            ParentFont = False
            TabOrder = 3
            OnClick = btnFacts1990sClick
          end
          object btnFacts2010s: TButton
            Left = 32
            Top = 272
            Width = 129
            Height = 73
            Caption = '2010s'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Script'
            Font.Style = []
            ParentFont = False
            TabOrder = 4
            OnClick = btnFacts2010sClick
          end
          object btnAllFacts: TButton
            Left = 208
            Top = 272
            Width = 129
            Height = 73
            Caption = 'All Facts'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Script'
            Font.Style = []
            ParentFont = False
            TabOrder = 5
            OnClick = btnAllFactsClick
          end
          object btnFactsBack1: TButton
            Left = 144
            Top = 360
            Width = 75
            Height = 25
            Caption = 'Back'
            TabOrder = 6
            OnClick = btnFactsBack1Click
          end
        end
        object pnlDisplayFacts: TPanel
          Left = 330
          Top = 36
          Width = 529
          Height = 398
          Color = clAntiquewhite
          ParentBackground = False
          TabOrder = 1
          object lblEraFacts: TLabel
            Left = 104
            Top = 8
            Width = 325
            Height = 43
            Caption = 'Fashion facts of the 1920s'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object memFacts: TMemo
            Left = 18
            Top = 80
            Width = 495
            Height = 258
            Lines.Strings = (
              'memFacts')
            ReadOnly = True
            ScrollBars = ssBoth
            TabOrder = 0
          end
          object btnFactsBack2: TButton
            Left = 232
            Top = 359
            Width = 75
            Height = 25
            Caption = 'Back'
            TabOrder = 1
            OnClick = btnFactsBack2Click
          end
        end
      end
    end
    object tabFashionHistoryQuiz: TTabSheet
      Caption = 'Fashion History Quiz'
      ImageIndex = 3
      object pnlMainQuizBackground: TPanel
        Left = 0
        Top = 0
        Width = 765
        Height = 470
        Color = clCoral
        ParentBackground = False
        TabOrder = 0
        object pnlMainQuizQuestions: TPanel
          Left = 8
          Top = 31
          Width = 577
          Height = 249
          Color = clBisque
          ParentBackground = False
          TabOrder = 0
          object lblMainQuizQuestionText: TLabel
            Left = 16
            Top = 16
            Width = 75
            Height = 20
            Caption = '<Question>'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -13
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object lblMainQuizQuestionNumber: TLabel
            Left = 516
            Top = 217
            Width = 45
            Height = 28
            Caption = '1/10'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object lblMainCorrect: TLabel
            Left = 304
            Top = 213
            Width = 191
            Height = 34
            Caption = 'Correct/Incorrect'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -21
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object rgbMainQuizAnswerOptions: TRadioGroup
            Left = 16
            Top = 42
            Width = 545
            Height = 169
            Items.Strings = (
              'Option A'
              'Option B'
              'Option C'
              'Option D')
            TabOrder = 0
          end
          object btnMainQuizExit: TButton
            Left = 16
            Top = 217
            Width = 57
            Height = 25
            Caption = 'Exit'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
            OnClick = btnMainQuizExitClick
          end
          object btnMainQuizNext: TButton
            Left = 96
            Top = 217
            Width = 57
            Height = 25
            Caption = 'Next'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 2
            OnClick = btnMainQuizNextClick
          end
        end
        object pnlMainQuizFinalScore: TPanel
          Left = 351
          Top = -88
          Width = 433
          Height = 330
          Color = clBisque
          ParentBackground = False
          TabOrder = 1
          object lblMainQuizFinalScore: TLabel
            Left = 135
            Top = 23
            Width = 169
            Height = 44
            Caption = 'Final Score:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -27
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object lblMainScore: TLabel
            Left = 167
            Top = 79
            Width = 102
            Height = 61
            Caption = '8/10'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -37
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object lblMainQuizMessage: TLabel
            Left = 7
            Top = 247
            Width = 268
            Height = 26
            Caption = 'Motivational Message towards '#39'user'#39
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = 'Segoe Print'
            Font.Style = []
            ParentFont = False
          end
          object btnMainQuizFinalScoreExit: TButton
            Left = 128
            Top = 160
            Width = 185
            Height = 81
            Caption = 'Exit'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -21
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
            OnClick = btnMainQuizFinalScoreExitClick
          end
        end
      end
    end
    object tabEraQuizGame: TTabSheet
      Caption = 'Era Quiz Game'
      ImageIndex = 4
      object pnlEraQuizBackground: TPanel
        Left = -12
        Top = -27
        Width = 765
        Height = 470
        Color = clMediumseagreen
        ParentBackground = False
        TabOrder = 0
        object pnlEraQuizQuestions: TPanel
          Left = 108
          Top = 110
          Width = 577
          Height = 249
          Color = clCornsilk
          ParentBackground = False
          TabOrder = 0
          DesignSize = (
            577
            249)
          object lblEraQuizFact: TLabel
            Left = 16
            Top = 8
            Width = 43
            Height = 23
            Caption = '<Fact>'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -13
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object lblEraQuizTime: TLabel
            Left = 224
            Top = 209
            Width = 12
            Height = 28
            Caption = '0'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object lblEraCorrect: TLabel
            Left = 359
            Top = 209
            Width = 191
            Height = 34
            Alignment = taCenter
            Anchors = [akTop]
            Caption = 'Correct/Incorrect'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -21
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object rgbEraQuizOptions: TRadioGroup
            Left = 16
            Top = 34
            Width = 545
            Height = 169
            Items.Strings = (
              '1920s'
              '1950s'
              '1970s'
              '1990s'
              '2010s')
            TabOrder = 0
            OnClick = rgbEraQuizOptionsClick
          end
          object btnEraQuizExit: TButton
            Left = 16
            Top = 217
            Width = 57
            Height = 25
            Caption = 'Exit'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
            OnClick = btnMainQuizExitClick
          end
        end
        object pnlEraQuizFinalScore: TPanel
          Left = 356
          Top = -17
          Width = 433
          Height = 330
          Color = clCornsilk
          ParentBackground = False
          TabOrder = 1
          object lblEraQuizFinalScoreHeading: TLabel
            Left = 135
            Top = 23
            Width = 169
            Height = 44
            Caption = 'Final Score:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -27
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object lblEraQuizFinalScore: TLabel
            Left = 207
            Top = 73
            Width = 27
            Height = 61
            Caption = '6'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -37
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold]
            ParentFont = False
          end
          object lblEraMessage: TLabel
            Left = 23
            Top = 251
            Width = 360
            Height = 30
            Caption = 'Motivational Message towards '#39'user'#39
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -19
            Font.Name = 'Segoe Script'
            Font.Style = []
            ParentFont = False
          end
          object btnEraQuizFinalScoreExit: TButton
            Left = 127
            Top = 156
            Width = 186
            Height = 83
            Caption = 'Exit'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -21
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
            OnClick = btnMainQuizFinalScoreExitClick
          end
        end
      end
    end
    object tabAdmin: TTabSheet
      Caption = 'Admin Tools'
      ImageIndex = 5
      object pnlAdminToolsBackground: TPanel
        Left = 3
        Top = 3
        Width = 747
        Height = 438
        Color = clBisque
        ParentBackground = False
        TabOrder = 0
        object pnlAdminToolsOptions: TPanel
          Left = -144
          Top = 396
          Width = 305
          Height = 321
          Color = clLemonchiffon
          ParentBackground = False
          TabOrder = 0
          object lblAdminToolsOptions: TLabel
            Left = 80
            Top = 16
            Width = 149
            Height = 34
            Caption = 'Admin Tools:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -21
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object btnAdminToolsManageFacts: TButton
            Left = 72
            Top = 64
            Width = 161
            Height = 65
            Caption = 'Manage Facts'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
          end
          object btnAdminToolsManageQuestions: TButton
            Left = 72
            Top = 144
            Width = 161
            Height = 65
            Caption = 'Manage Questions'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
          end
          object btnAdminToolsViewResults: TButton
            Left = 72
            Top = 224
            Width = 161
            Height = 65
            Caption = 'View Results'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 2
            OnClick = btnAdminToolsViewResultsClick
          end
        end
        object pnlManageFacts: TPanel
          Left = 494
          Top = 396
          Width = 305
          Height = 345
          Color = clLavenderblush
          ParentBackground = False
          TabOrder = 1
          object lblManageFacts: TLabel
            Left = 80
            Top = 16
            Width = 153
            Height = 34
            Caption = 'Manage Facts:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -21
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object btnAddFacts: TButton
            Left = 72
            Top = 65
            Width = 169
            Height = 65
            Caption = 'Add Facts'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
          end
          object btnDeleteFacts: TButton
            Left = 72
            Top = 144
            Width = 169
            Height = 65
            Caption = 'Delete Facts'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
          end
          object btnEditFacts: TButton
            Left = 72
            Top = 224
            Width = 169
            Height = 65
            Caption = 'Edit Facts'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 2
          end
          object btnFactsBAck: TButton
            Left = 128
            Top = 303
            Width = 57
            Height = 30
            Caption = 'Back'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 3
            OnClick = btnFactsBAckClick
          end
        end
        object pnlManageQuestions: TPanel
          Left = 167
          Top = 396
          Width = 305
          Height = 345
          Color = clLavenderblush
          ParentBackground = False
          TabOrder = 2
          object lblManageQuestions: TLabel
            Left = 56
            Top = 3
            Width = 207
            Height = 34
            Caption = 'Manage Questions:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -21
            Font.Name = 'Segoe Script'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object btnAddQuestions: TButton
            Left = 72
            Top = 65
            Width = 169
            Height = 65
            Caption = 'Add Questions'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
          end
          object btnDeleteQuestions: TButton
            Left = 72
            Top = 144
            Width = 169
            Height = 65
            Caption = 'Delete Questions'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
          end
          object btnEditQuestions: TButton
            Left = 72
            Top = 224
            Width = 169
            Height = 65
            Caption = 'Edit Questions'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 2
          end
          object btnQuestionsBack: TButton
            Left = 128
            Top = 303
            Width = 58
            Height = 34
            Caption = 'Back'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 3
            OnClick = btnQuestionsBackClick
          end
        end
        object btnAdminToolsOptionsBack: TButton
          Left = 24
          Top = 19
          Width = 73
          Height = 25
          Caption = 'Exit'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Segoe Print'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 3
          OnClick = btnAdminToolsOptionsBackClick
        end
        object pnlManaging: TPanel
          Left = 24
          Top = 67
          Width = 697
          Height = 323
          Color = clCream
          ParentBackground = False
          TabOrder = 4
          object lblManaging: TLabel
            Left = 175
            Top = 3
            Width = 162
            Height = 15
            Caption = '<Manage Facts> (<--Example)'
          end
          object lstQuizData: TListBox
            Left = 175
            Top = 24
            Width = 498
            Height = 273
            ItemHeight = 15
            TabOrder = 0
          end
          object btnSeeFactsOrQuestions: TButton
            Left = 16
            Top = 272
            Width = 137
            Height = 25
            Caption = 'Display <Facts>'
            TabOrder = 1
          end
          object edtManaging: TEdit
            Left = 16
            Top = 32
            Width = 137
            Height = 23
            TabOrder = 2
          end
          object btnAddAndDelete: TButton
            Left = 48
            Top = 72
            Width = 75
            Height = 25
            Caption = 'Add/Delete'
            TabOrder = 3
          end
          object btnUpdate: TButton
            Left = 48
            Top = 103
            Width = 75
            Height = 25
            Caption = 'Update'
            TabOrder = 4
          end
        end
      end
    end
    object tabResults: TTabSheet
      Caption = 'Results'
      ImageIndex = 6
      object pnlResultsBackground: TPanel
        Left = 0
        Top = 3
        Width = 753
        Height = 438
        Color = clBisque
        ParentBackground = False
        TabOrder = 0
        object pnlResultsOptions: TPanel
          Left = 33
          Top = 48
          Width = 385
          Height = 225
          Color = clCream
          ParentBackground = False
          TabOrder = 0
          object lblResultsOptions: TLabel
            Left = 160
            Top = 16
            Width = 72
            Height = 33
            Caption = 'Results:'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -19
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object btnResultsBestScore: TButton
            Left = 48
            Top = 72
            Width = 129
            Height = 57
            Caption = 'Best Score'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
          end
          object btnAverageScore: TButton
            Left = 208
            Top = 72
            Width = 129
            Height = 57
            Caption = 'Average Score'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
          end
          object btnAllResults: TButton
            Left = 136
            Top = 152
            Width = 121
            Height = 41
            Caption = 'All Results'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 2
          end
          object btnResultsBack: TButton
            Left = 16
            Top = 16
            Width = 65
            Height = 25
            Caption = 'Back'
            TabOrder = 3
          end
        end
        object pnlResultsFormatted: TPanel
          Left = 456
          Top = 40
          Width = 273
          Height = 297
          TabOrder = 1
          object lblResultsHeading: TLabel
            Left = 24
            Top = 26
            Width = 217
            Height = 28
            Caption = '<All Results> (<--Example)'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -16
            Font.Name = 'Segoe Print'
            Font.Style = [fsBold, fsUnderline]
            ParentFont = False
          end
          object memResults: TMemo
            Left = 32
            Top = 74
            Width = 209
            Height = 159
            Lines.Strings = (
              'memResults')
            TabOrder = 0
          end
          object btnResultsFormattedBack: TButton
            Left = 96
            Top = 256
            Width = 75
            Height = 25
            Caption = 'Back'
            TabOrder = 1
          end
        end
      end
    end
  end
  object tmrEraQuizTime: TTimer
    Enabled = False
    Interval = 10
    OnTimer = tmrEraQuizTimeTimer
    Left = 48
    Top = 399
  end
end
