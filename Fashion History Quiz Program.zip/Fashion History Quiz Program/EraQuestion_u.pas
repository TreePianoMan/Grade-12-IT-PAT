unit EraQuestion_u;

interface

type

TEraQuestion = class

private
    fFact : string;
    fCorrectEra : string;
    fUsed : Boolean;

  public
    constructor Create(sFact, sEra : string);

    function GetFact : string;
    function CheckAnswer(sAnswer : string) : Boolean;
    function GetUsed : Boolean;
    procedure SetUsed(bUsed : Boolean);

  end;

implementation

{ TEraQuestion }

{ TEraQuestion }

function TEraQuestion.CheckAnswer(sAnswer: string): Boolean;
begin

 Result := sAnswer = fCorrectEra;

end;

constructor TEraQuestion.Create(sFact, sEra: string);
begin

  fFact := sFact;
  fCorrectEra := sEra;
  fUsed := False;

end;

function TEraQuestion.GetFact: string;
begin

 Result := fFact;

end;

function TEraQuestion.GetUsed: Boolean;
begin

 Result := fUsed;

end;

procedure TEraQuestion.SetUsed(bUsed: Boolean);
begin

 fUsed := bUsed;

end;

end.
