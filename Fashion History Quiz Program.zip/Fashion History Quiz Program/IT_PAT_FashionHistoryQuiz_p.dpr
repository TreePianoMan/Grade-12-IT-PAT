program IT_PAT_FashionHistoryQuiz_p;

uses
  Vcl.Forms,
  IT_PAT_FashionHistoryQuiz_u in 'IT_PAT_FashionHistoryQuiz_u.pas' {frmHistory_of_Fashion_Quiz},
  dmQuizData_u in 'dmQuizData_u.pas' {dmQuizData: TDataModule},
  EraQuestion_u in 'EraQuestion_u.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmHistory_of_Fashion_Quiz, frmHistory_of_Fashion_Quiz);
  Application.CreateForm(TdmQuizData, dmQuizData);
  Application.Run;
end.
