unit dmQuizData_u;

interface

uses
  System.SysUtils, System.Classes, Data.DB, Data.Win.ADODB;

type
  TdmQuizData = class(TDataModule)
    conQuizData: TADOConnection;
    qrySQL: TADOQuery;
    dsrQuizData: TDataSource;
    procedure DataModuleCreate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  dmQuizData: TdmQuizData;

implementation

{%CLASSGROUP 'Vcl.Controls.TControl'}

{$R *.dfm}

procedure TdmQuizData.DataModuleCreate(Sender: TObject);
begin
conQuizData.Connectionstring := 'Provider='
+ 'Microsoft.Jet.OLEDB.4.0;'
+ 'Data Source='
+ ExtractFilePath(ParamStr(0)) + 'QuizData.mdb;'
+ 'Persist Security Info=False';
conQuizData.LoginPrompt := false;
conQuizData.Open;
end;

end.
