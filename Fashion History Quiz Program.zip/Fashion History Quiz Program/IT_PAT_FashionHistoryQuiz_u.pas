unit IT_PAT_FashionHistoryQuiz_u;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls, Vcl.ExtCtrls, Vcl.ComCtrls, dmQuizData_u, EraQuestion_u;

type
  TfrmHistory_of_Fashion_Quiz = class(TForm)
    PageControl: TPageControl;
    tabLogin: TTabSheet;
    tabHome: TTabSheet;
    tabFacts: TTabSheet;
    tabFashionHistoryQuiz: TTabSheet;
    tabEraQuizGame: TTabSheet;
    tabAdmin: TTabSheet;
    tabResults: TTabSheet;
    pnlLogin: TPanel;
    lblLoginHeading: TLabel;
    lblLogin: TLabel;
    edtLoginUsername: TEdit;
    edtLoginPassword: TEdit;
    lblLoginDescription: TLabel;
    lblLoginPassword: TLabel;
    lblLoginUsername: TLabel;
    lblLoginSignUpOption: TLabel;
    btnLogin: TButton;
    pnlSignup: TPanel;
    lblSignupHeading: TLabel;
    lblSignup: TLabel;
    lblSignupDescription: TLabel;
    lblSignupPassword: TLabel;
    lblSignupUsername: TLabel;
    edtSignupUsername: TEdit;
    edtSignupPassword: TEdit;
    btnSignup: TButton;
    btnSignupBack: TButton;
    pnlHomepage: TPanel;
    lblHomepageHeading: TLabel;
    btnHomepageFacts: TButton;
    btnHomepageMainQuiz: TButton;
    btnHomepageEraQuiz: TButton;
    lblWelcomeUserBlack: TLabel;
    lblWelcomeUserWhite: TLabel;
    lblFashionHistoryHeadingWhite: TLabel;
    btnHomepageAdminTools: TButton;
    pnlFactsBackground: TPanel;
    pnlFactsPickEra: TPanel;
    lblFactsPickEra: TLabel;
    btnFacts1920s: TButton;
    btnFacts1950s: TButton;
    btnFacts1970s: TButton;
    btnFacts1990s: TButton;
    btnFacts2010s: TButton;
    btnAllFacts: TButton;
    pnlDisplayFacts: TPanel;
    lblEraFacts: TLabel;
    memFacts: TMemo;
    btnFactsBack1: TButton;
    btnFactsBack2: TButton;
    pnlMainQuizBackground: TPanel;
    pnlMainQuizQuestions: TPanel;
    lblMainQuizQuestionText: TLabel;
    rgbMainQuizAnswerOptions: TRadioGroup;
    pnlMainQuizFinalScore: TPanel;
    lblMainQuizFinalScore: TLabel;
    lblMainScore: TLabel;
    lblMainQuizMessage: TLabel;
    btnMainQuizFinalScoreExit: TButton;
    btnMainQuizExit: TButton;
    btnMainQuizNext: TButton;
    lblMainQuizQuestionNumber: TLabel;
    pnlEraQuizBackground: TPanel;
    pnlEraQuizQuestions: TPanel;
    lblEraQuizFact: TLabel;
    lblEraQuizTime: TLabel;
    rgbEraQuizOptions: TRadioGroup;
    btnEraQuizExit: TButton;
    pnlEraQuizFinalScore: TPanel;
    lblEraQuizFinalScoreHeading: TLabel;
    lblEraQuizFinalScore: TLabel;
    lblEraMessage: TLabel;
    btnEraQuizFinalScoreExit: TButton;
    tmrEraQuizTime: TTimer;
    pnlAdminToolsBackground: TPanel;
    pnlAdminToolsOptions: TPanel;
    btnAdminToolsManageFacts: TButton;
    lblAdminToolsOptions: TLabel;
    btnAdminToolsManageQuestions: TButton;
    btnAdminToolsViewResults: TButton;
    pnlManageFacts: TPanel;
    lblManageFacts: TLabel;
    btnAddFacts: TButton;
    btnDeleteFacts: TButton;
    btnEditFacts: TButton;
    pnlManageQuestions: TPanel;
    lblManageQuestions: TLabel;
    btnAddQuestions: TButton;
    btnDeleteQuestions: TButton;
    btnEditQuestions: TButton;
    btnAdminToolsOptionsBack: TButton;
    btnFactsBAck: TButton;
    btnQuestionsBack: TButton;
    pnlManaging: TPanel;
    lstQuizData: TListBox;
    btnSeeFactsOrQuestions: TButton;
    lblManaging: TLabel;
    edtManaging: TEdit;
    btnAddAndDelete: TButton;
    btnUpdate: TButton;
    pnlResultsBackground: TPanel;
    pnlResultsOptions: TPanel;
    lblResultsOptions: TLabel;
    btnResultsBestScore: TButton;
    btnAverageScore: TButton;
    btnAllResults: TButton;
    pnlResultsFormatted: TPanel;
    lblResultsHeading: TLabel;
    memResults: TMemo;
    btnResultsFormattedBack: TButton;
    btnResultsBack: TButton;
    cbxHidePassword: TCheckBox;
    lblEraCorrect: TLabel;
    lblMainCorrect: TLabel;
    procedure lblLoginSignUpOptionMouseEnter(Sender: TObject);
    procedure lblLoginSignUpOptionMouseLeave(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure lblLoginSignUpOptionClick(Sender: TObject);
    procedure btnSignupBackClick(Sender: TObject);
    procedure btnLoginClick(Sender: TObject);
    procedure btnSignupClick(Sender: TObject);
    procedure btnHomepageFactsClick(Sender: TObject);
    procedure btnFactsBack1Click(Sender: TObject);
    procedure btnFactsBack2Click(Sender: TObject);
    procedure btnFacts1920sClick(Sender: TObject);
    procedure btnFacts1950sClick(Sender: TObject);
    procedure btnFacts1970sClick(Sender: TObject);
    procedure btnFacts1990sClick(Sender: TObject);
    procedure btnFacts2010sClick(Sender: TObject);
    procedure btnAllFactsClick(Sender: TObject);
    procedure btnHomepageMainQuizClick(Sender: TObject);
    procedure btnHomepageEraQuizClick(Sender: TObject);
    procedure btnHomepageAdminToolsClick(Sender: TObject);
    procedure btnMainQuizNextClick(Sender: TObject);
    procedure btnMainQuizExitClick(Sender: TObject);
    procedure btnMainQuizFinalScoreExitClick(Sender: TObject);
    procedure tmrEraQuizTimeTimer(Sender: TObject);
    procedure btnEraQuizQuestionsNextClick(Sender: TObject);
    procedure btnAdminToolsViewResultsClick(Sender: TObject);
    procedure btnAdminToolsOptionsBackClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnQuestionsBackClick(Sender: TObject);
    procedure btnFactsBAckClick(Sender: TObject);
    procedure cbxHidePasswordClick(Sender: TObject);
    procedure LoadFacts(sEra : string);
    procedure LoadEraQuestions;
    procedure LoadMainQuestions;
    procedure DisplayMainQuestion;
    procedure ShowRandomFact;
    procedure rgbEraQuizOptionsClick(Sender: TObject);
    procedure ShowResults;
  private
    { Private declarations }
  iMainQuizQuestionNumber : integer;
  rTimeLeft: Real;
  sCurrentUser : string;
  sCurrentRole : string;
  iScore : Integer;
  iEraQuestionNo : Integer;
  public
    { Public declarations }
  end;

const
  MAXFACTS = 30;
  MAXQUESTIONS = 10;

var
  frmHistory_of_Fashion_Quiz: TfrmHistory_of_Fashion_Quiz;
  objEra : TEraQuestion;
  arrEraQuestions : array[1..MAXFACTS] of TEraQuestion;
  arrMainQuestions : array[1..MAXQUESTIONS,1..6] of String;
  iTotalFacts : Integer;
  iCurrentFact : Integer;
  iCurrentQuestion : Integer;

implementation

{$R *.dfm}

procedure TfrmHistory_of_Fashion_Quiz.btnAdminToolsOptionsBackClick(
  Sender: TObject);
begin

 pnlAdminToolsOptions.Show;
 pnlManageFacts.Hide;
 pnlManageQuestions.Hide;

  PageControl.ActivePage := tabHome;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnAdminToolsViewResultsClick(
  Sender: TObject);
begin

 PageControl.ActivePage := tabResults;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnAllFactsClick(Sender: TObject);
begin
// rememeber change pnlDisplayFacts lblEraFacts to All Facts

 lblEraFacts.Caption := 'All Fashion Facts';
 lblEraFacts.Left := 169;

  LoadFacts('ALL');

 pnlDisplayFacts.Show;
 pnlFactsPickEra.Hide;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnEraQuizQuestionsNextClick(
  Sender: TObject);
begin
  // Change fact/question and update score if correct
  if rgbEraQuizOptions.ItemIndex <> -1 then
  begin
    if arrEraQuestions[iCurrentFact].CheckAnswer(
      rgbEraQuizOptions.Items[rgbEraQuizOptions.ItemIndex]) then
    begin
      Inc(iScore);
      lblEraCorrect.Caption := 'Correct!';
      lblEraCorrect.Font.Color := clGreen;
    end
    else
    begin
      lblEraCorrect.Caption := 'Incorrect!';
      lblEraCorrect.Font.Color := clRed;
    end;

    ShowRandomFact;
  end
  else
  begin
    lblEraCorrect.Caption := 'No era chosen.';
    lblEraCorrect.Font.Color := clRed;
  end;
end;

procedure TfrmHistory_of_Fashion_Quiz.btnFacts1920sClick(Sender: TObject);
begin
 // rememeber change pnlDisplayFacts lblEraFacts to whatever era is chosen

 lblEraFacts.Caption := 'Fashion facts of the 1920s';


 LoadFacts('1920s');


 pnlDisplayFacts.Show;
 pnlFactsPickEra.Hide;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnFacts1950sClick(Sender: TObject);
begin

// rememeber change pnlDisplayFacts lblEraFacts to whatever era is chosen

 lblEraFacts.Caption := 'Fashion facts of the 1950s';

 LoadFacts('1950s');

 pnlDisplayFacts.Show;
 pnlFactsPickEra.Hide;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnFacts1970sClick(Sender: TObject);
begin

// rememeber change pnlDisplayFacts lblEraFacts to whatever era is chosen

 lblEraFacts.Caption := 'Fashion facts of the 1970s';

 LoadFacts('1970s');

 pnlDisplayFacts.Show;
 pnlFactsPickEra.Hide;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnFacts1990sClick(Sender: TObject);
begin

// rememeber change pnlDisplayFacts lblEraFacts to whatever era is chosen

 lblEraFacts.Caption := 'Fashion facts of the 1990s';

 LoadFacts('1990s');

 pnlDisplayFacts.Show;
 pnlFactsPickEra.Hide;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnFacts2010sClick(Sender: TObject);
begin
// rememeber change pnlDisplayFacts lblEraFacts to whatever era is chosen

 lblEraFacts.Caption := 'Fashion facts of the 2010s';

 LoadFacts('2010s');

 pnlDisplayFacts.Show;
 pnlFactsPickEra.Hide;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnFactsBack1Click(Sender: TObject);
begin

 PageControl.ActivePage := tabHome;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnFactsBack2Click(Sender: TObject);
begin

 lblEraFacts.Left := 104;

 pnlDisplayFacts.Hide;
 pnlFactsPickEra.Show;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnFactsBAckClick(Sender: TObject);
begin

 pnlManageFacts.Hide;
 pnlAdminToolsOptions.Show;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnHomepageAdminToolsClick(
  Sender: TObject);
begin

 PageControl.ActivePage := tabAdmin;
 pnlManageFacts.Hide;
 pnlManageQuestions.Hide;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnHomepageEraQuizClick(Sender: TObject);
begin

 iScore := 0;

 rTimeLeft := 20.00;
 tmrEraQuizTime.Enabled := True;

 lblEraCorrect.Font.Color := clBlack;
 lblEraCorrect.Caption := '...';

 LoadEraQuestions;
 ShowRandomFact;

 PageControl.ActivePage := tabEraQuizGame;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnHomepageFactsClick(Sender: TObject);
begin

 PageControl.ActivePage := tabFacts;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnHomepageMainQuizClick(Sender: TObject);
begin

 LoadMainQuestions;

 iMainQuizQuestionNumber := 1;
 iScore := 0;
 lblMainCorrect.Hide;

 DisplayMainQuestion;

 PageControl.ActivePage := tabFashionHistoryQuiz;

 lblMainQuizQuestionNumber.Caption := IntToStr(iMainQuizQuestionNumber) + '/10';

end;

procedure TfrmHistory_of_Fashion_Quiz.btnLoginClick(Sender: TObject);
var
sLoginUsername, sLoginPassword : string;
begin

  sLoginUsername := edtLoginUsername.Text;
  sLoginPassword := edtLoginPassword.Text;

  //SQL

  dmQuizData.qrySQL.Close;
  dmQuizData.qrySQL.SQL.Clear;
  dmQuizData.qrySQL.SQL.Add('SELECT * FROM tblUsers');
  dmQuizData.qrySQL.SQL.Add('WHERE Username = :Username');
  dmQuizData.qrySQL.SQL.Add('AND Password = :Password');

  dmQuizData.qrySQL.Parameters.ParamByName('Username').Value := sLoginUsername;
  dmQuizData.qrySQL.Parameters.ParamByName('Password').Value := sLoginPassword;

  dmQuizData.qrySQL.Open;


  //validation
  if dmQuizData.qrySQL.Eof then
 begin
  lblLoginDescription.Caption := 'Incorrect username or password.';
  lblLoginDescription.Font.Color := clRed;
  lblLoginDescription.Left := 280;
 end
 else
 begin

   //Takes user to Homepage and saves username in global variable for easy updates, etc...
  PageControl.ActivePage := tabHome;
  sCurrentUser := sLoginUsername;

  sCurrentRole := dmQuizData.qrySQL['Role'];

  if sCurrentRole = 'Administrator' then
  begin
  btnHomepageAdminTools.Enabled := True;
  end
  else
  begin
   btnHomepageAdminTools.Enabled := False;
  end;

  lblWelcomeUserBlack.Caption := 'WELCOME ' + sCurrentUser + '!';
  lblWelcomeUserWhite.Caption := 'WELCOME ' + sCurrentUser + '!';

  ShowMessage('Login successful!');  //idk if showmessage necessarry

 end;


end;

procedure TfrmHistory_of_Fashion_Quiz.btnMainQuizExitClick(Sender: TObject);
begin

 iMainQuizQuestionNumber := 1;

 PageControl.ActivePage := tabHome;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnMainQuizFinalScoreExitClick(
  Sender: TObject);
begin

 pnlMainQuizQuestions.Show;
 pnlMainQuizFinalScore.Hide;

 pnlEraQuizQuestions.Show;
 pnlEraQuizFinalScore.Hide;

 iMainQuizQuestionNumber := 1;
 PageControl.ActivePage := tabHome;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnMainQuizNextClick(Sender: TObject);
var
sAnswer : string;
begin

 if rgbMainQuizAnswerOptions.ItemIndex <> -1 then
 begin

  case rgbMainQuizAnswerOptions.ItemIndex of
   0: sAnswer := 'A';
   1: sAnswer := 'B';
   2: sAnswer := 'C';
   3: sAnswer := 'D';
  end;

   if sAnswer = arrMainQuestions[iMainQuizQuestionNumber, 6] then
       begin
        Inc(iScore);
        lblMainCorrect.Caption := 'Correct';
        lblMainCorrect.Font.Color := clGreen;
       end
       else
       begin
        lblMainCorrect.Caption := 'Incorrect';
        lblMainCorrect.Font.Color := clRed;
       end;


  Inc(iMainQuizQuestionNumber);
  lblMainQuizQuestionNumber.Caption := IntToStr(iMainQuizQuestionNumber) + '/10';

  if iMainQuizQuestionNumber > 1 then
   lblMainCorrect.Show;

  if iMainQuizQuestionNumber <= 10 then
   DisplayMainQuestion
  else
      ShowResults;

 end;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnQuestionsBackClick(Sender: TObject);
begin

 pnlManageQuestions.Hide;
 pnlAdminToolsOptions.Show;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnSignupBackClick(Sender: TObject);
begin

 pnlLogin.Show;
 pnlSignup.Hide;

end;

procedure TfrmHistory_of_Fashion_Quiz.btnSignupClick(Sender: TObject);
var
sSignupUsername, sSignupPassword : string;
begin

 sSignupUsername := Trim(edtSignupUsername.Text);
 sSignupPassword := Trim(edtSignupPassword.Text);

 //Validate Username
  if (Length(sSignupUsername) < 3) or (Length(sSignupUsername) > 20) then
  begin
    lblSignupUsername.Caption := 'Username must be between 3 and 20 characters.';
    lblSignupUsername.Font.Color := clRed;
    lblSignupPassword.Font.Color := clBlack;
    edtSignupUsername.SetFocus;
    Exit;
  end;

  //Validate Password
  if (Length(sSignupPassword) < 8) or (Length(sSignupPassword) > 20) then
  begin
    lblSignupPassword.Caption := 'Password must be between 8 and 20 characters.';
    lblSignupPassword.Font.Color := clRed;
    lblSignupUsername.Font.Color := clBlack;
    edtSignupPassword.SetFocus;
    Exit;
  end;

  //Check if username already exists  (SQL)
   dmQuizData.qrySQL.Close;
  dmQuizData.qrySQL.SQL.Clear;
  dmQuizData.qrySQL.SQL.Add('SELECT * FROM tblUsers');
  dmQuizData.qrySQL.SQL.Add('WHERE Username = :Username');

  dmQuizData.qrySQL.Parameters.ParamByName('Username').Value := sSignupUsername;
  dmQuizData.qrySQL.Open;

  if not dmQuizData.qrySQL.Eof then
  begin
    ShowMessage('That username already exists. Please choose another one.');
    lblSignupUsername.Font.Color := clRed;
    lblSignupPassword.Font.Color := clBlack;
    edtSignupUsername.SetFocus;
    Exit;
  end;

  //Add the new user
   dmQuizData.qrySQL.Close;
   dmQuizData.qrySQL.SQL.Clear;
   dmQuizData.qrySQL.SQL.Add('INSERT INTO tblUsers (Username, [Password], Role) ' +
                             'VALUES (:Username, :Password, :Role)');

   dmQuizData.qrySQL.Parameters.ParamByName('Username').Value := sSignupUsername;
   dmQuizData.qrySQL.Parameters.ParamByName('Password').Value := sSignupPassword;
   dmQuizData.qrySQL.Parameters.ParamByName('Role').Value := 'Learner';

   dmQuizData.qrySQL.ExecSQL;


   //Takes user back to Login screen once acc is created, ^^^ howevr if the 'username' is already taken then it'll change the lblSignupUsername to clRed and Display 'Username is already taken, please try again.'
    PageControl.ActivePage := tabLogin;


   ShowMessage('Account created successfully!');


end;

procedure TfrmHistory_of_Fashion_Quiz.cbxHidePasswordClick(Sender: TObject);
begin

  if cbxHidePassword.Checked then
    edtLoginPassword.PasswordChar := '*'      // Show password
  else
    edtLoginPassword.PasswordChar := #0;    // Hide password

end;

procedure TfrmHistory_of_Fashion_Quiz.DisplayMainQuestion;
begin

 begin
  lblMainQuizQuestionText.Caption := arrMainQuestions[iMainQuizQuestionNumber, 1];

  rgbMainQuizAnswerOptions.Items[0] := arrMainQuestions[iMainQuizQuestionNumber, 2];
  rgbMainQuizAnswerOptions.Items[1] := arrMainQuestions[iMainQuizQuestionNumber, 3];
  rgbMainQuizAnswerOptions.Items[2] := arrMainQuestions[iMainQuizQuestionNumber, 4];
  rgbMainQuizAnswerOptions.Items[3] := arrMainQuestions[iMainQuizQuestionNumber, 5];

  rgbMainQuizAnswerOptions.ItemIndex := -1;
 end;

end;

procedure TfrmHistory_of_Fashion_Quiz.FormActivate(Sender: TObject);
begin

 iMainQuizQuestionNumber := 1; //initilise variables

 lblLoginSignUpOption.Font.Color := clBlack;  //label colour

 pnlLogin.Show;    //defaut visible/invisible tabs on startup
 pnlSignup.Hide;
  pnlDisplayFacts.Hide;
  pnlFactsPickEra.Show;
   pnlMainQuizQuestions.Show;
   pnlMainQuizFinalScore.Hide;
    pnlEraQuizQuestions.Show;
    pnlEraQuizFinalScore.Hide;

 PageControl.Style := tsFlatButtons;  //Make tabs at top invisible when running program
 PageControl.TabHeight := 1;

 frmHistory_of_Fashion_Quiz.Height := 511; //Form size
 frmHistory_of_Fashion_Quiz.Width := 782;

 btnHomepageAdminTools.Enabled := true; //Admin Tools are not available on startup

 PageControl.ActivePage := tabLogin;  //First active tabsheet

 lblSignupUsername.Font.Color := clBlack; //label defaults
 lblSignupPassword.Font.Color := clBlack;
 lblLoginDescription.Font.Color := clBlack;
 lblLoginDescription.Caption := 'Please enter your username and password.';
 lblLoginDescription.Left := 256;

end;

procedure TfrmHistory_of_Fashion_Quiz.FormCreate(Sender: TObject);
begin

 pnlLogin.Left := 0;     //Set panel sizes and positions
 pnlLogin.Top := 0;
 pnlLogin.Height := 470;
 pnlLogin.Width := 765;

 pnlSignup.Left := 0;
 pnlSignup.Top := 0;
 pnlSignup.Height := 470;
 pnlSignup.Width := 765;

 pnlHomepage.Left := 0;
 pnlHomepage.Top := 0;
 pnlHomepage.Height := 470;
 pnlHomepage.Width := 765;

 pnlFactsPickEra.Left := 192;
 pnlFactsPickEra.Top := 16;
 pnlFactsPickEra.Height := 401;
 pnlFactsPickEra.Width := 369;

 pnlFactsBackground.Left := 0;
 pnlFactsBackground.Top := 0;
 pnlFactsBackground.Height := 470;
 pnlFactsBackground.Width := 765;

 pnlDisplayFacts.Left := 128;
 pnlDisplayFacts.Top := 29;
 pnlDisplayFacts.Height := 398;
 pnlDisplayFacts.Width := 529;

 pnlMainQuizQuestions.Left := 88;
 pnlMainQuizQuestions.Top := 40;
 pnlMainQuizQuestions.Height := 353;
 pnlMainQuizQuestions.Width := 577;

 pnlMainQuizFinalScore.Left := 167;
 pnlMainQuizFinalScore.Top := 55;
 pnlMainQuizFinalScore.Height := 330;
 pnlMainQuizFinalScore.Width := 433;

 pnlEraQuizQuestions.Left := 88;
 pnlEraQuizQuestions.Top := 110;
 pnlEraQuizQuestions.Height := 249;
 pnlEraQuizQuestions.Width := 577;

 pnlEraQuizFinalScore.Left := 167;
 pnlEraQuizFinalScore.Top := 55;
 pnlEraQuizFinalScore.Height := 330;
 pnlEraQuizFinalScore.Width := 433;

 pnlAdminToolsOptions.Left := 224;
 pnlAdminToolsOptions.Top := 58;
 pnlAdminToolsOptions.Height := 321;
 pnlAdminToolsOptions.Width := 305;

 pnlManageQuestions.Left := 223;
 pnlManageQuestions.Top := 44;
 pnlManageQuestions.Height := 345;
 pnlManageQuestions.Width := 305;

 pnlManageFacts.Left := 223;
 pnlManageFacts.Top := 44;
 pnlManageFacts.Height := 345;
 pnlManageFacts.Width := 305;

 pnlManaging.Left := 24;
 pnlManaging.Top := 67;
 pnlManaging.Height := 323;
 pnlManaging.Width := 697;

end;

procedure TfrmHistory_of_Fashion_Quiz.lblLoginSignUpOptionClick(
  Sender: TObject);
begin
 //Takes the user to the sign-up screen

 pnlLogin.Hide;
 pnlSignup.Show;

 //Reset Login Page
 edtLoginUsername.Text := '';
 edtLoginPassword.Text := '';

 lblLoginDescription.Caption := 'Please enter your username and password.';
 lblLoginDescription.Font.Color := clBlack;
 lblLoginDescription.Left := 256;

 //Reset Sign-up Page
 lblSignupUsername.Font.Color := clBlack;
 lblSignupPassword.Font.Color := clBlack;
 edtSignupUsername.Text := '';
 edtSignupPassword.Text := '';

end;

procedure TfrmHistory_of_Fashion_Quiz.lblLoginSignUpOptionMouseEnter(
  Sender: TObject);
begin

 lblLoginSignUpOption.Font.Color := clHighlight;

end;

procedure TfrmHistory_of_Fashion_Quiz.lblLoginSignUpOptionMouseLeave(
  Sender: TObject);
begin

 lblLoginSignUpOption.Font.Color := clBlack;

end;


procedure TfrmHistory_of_Fashion_Quiz.LoadEraQuestions;
begin

  iTotalFacts := 0;

  with dmQuizData.qrySQL do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT tblFashionFact.FactText,');
    SQL.Add('tblEra.[Era Name]');
    SQL.Add('FROM tblFashionFact');
    SQL.Add('INNER JOIN tblEra');
    SQL.Add('ON tblFashionFact.EraID = tblEra.EraID');
    Open;

    while not Eof do
    begin
      Inc(iTotalFacts);

      arrEraQuestions[iTotalFacts] := TEraQuestion.Create(
        FieldByName('FactText').AsString,
        FieldByName('Era Name').AsString);

      Next;
    end;
  end;

end;

procedure TfrmHistory_of_Fashion_Quiz.LoadFacts(sEra: string);  //LoadFacts procedure
var
  sCurrentEra : string;
begin
  memFacts.Clear;

  with dmQuizData.qrySQL do                        //SQL
  begin
    Close;
    SQL.Clear;

    SQL.Add('SELECT tblEra.[Era Name],');
    SQL.Add('tblEra.Description,');
    SQL.Add('tblEra.[Style Characteristics],');
    SQL.Add('tblEra.[Popular Item],');
    SQL.Add('tblFashionFact.FactText');
    SQL.Add('FROM tblEra');
    SQL.Add('INNER JOIN tblFashionFact');
    SQL.Add('ON tblEra.EraID = tblFashionFact.EraID');

    //If a specific era was chosen
    if sEra <> 'ALL' then
    begin
      SQL.Add('WHERE tblEra.[Era Name] = :Era');
    end;

    SQL.Add('ORDER BY tblEra.[Era Name]');

    if sEra <> 'ALL' then
      Parameters.ParamByName('Era').Value := sEra;

    Open;

    if Eof then
    begin
      ShowMessage('No fashion facts found.');
      Exit;
    end;

    sCurrentEra := '';

    while not Eof do
    begin

      if FieldByName('Era Name').AsString <> sCurrentEra then
      begin
        sCurrentEra := FieldByName('Era Name').AsString;

        memFacts.Lines.Add('==========================================================');
        memFacts.Lines.Add(sCurrentEra);
        memFacts.Lines.Add('==========================================================');
        memFacts.Lines.Add('');

        memFacts.Lines.Add('Description:');
        memFacts.Lines.Add(FieldByName('Description').AsString);
        memFacts.Lines.Add('');

        memFacts.Lines.Add('Style Characteristics:');
        memFacts.Lines.Add(FieldByName('Style Characteristics').AsString);
        memFacts.Lines.Add('');

        memFacts.Lines.Add('Popular Item:');
        memFacts.Lines.Add(FieldByName('Popular Item').AsString);
        memFacts.Lines.Add('');

        memFacts.Lines.Add('Fashion Facts');
        memFacts.Lines.Add('-----------------------------------------------------------------------------------------------');
      end;

      memFacts.Lines.Add('� ' + FieldByName('FactText').AsString);
      memFacts.Lines.Add('');

      Next;
    end;
  end;
end;



procedure TfrmHistory_of_Fashion_Quiz.LoadMainQuestions;
begin

 var
  i : Integer;
begin
  i := 1;

  with dmQuizData.qrySQL do
  begin
    Close;

    SQL.Clear;
    SQL.Add('SELECT TOP 10 *');
    SQL.Add('FROM tblQuestion');
    SQL.Add('ORDER BY Rnd(QuestionID)');

    Open;

    while not EOF do
    begin
      arrMainQuestions[i,1] := FieldByName('Question Text').AsString;
      arrMainQuestions[i,2] := FieldByName('Option A').AsString;
      arrMainQuestions[i,3] := FieldByName('Option B').AsString;
      arrMainQuestions[i,4] := FieldByName('Option C').AsString;
      arrMainQuestions[i,5] := FieldByName('Option D').AsString;
      arrMainQuestions[i,6] := FieldByName('Correct Answer').AsString;

      Inc(i);
      Next;
    end;
  end;
end;

end;

procedure TfrmHistory_of_Fashion_Quiz.rgbEraQuizOptionsClick(Sender: TObject);
begin

  // Change fact/question and update score if correct
  if rgbEraQuizOptions.ItemIndex <> -1 then
  begin
    if arrEraQuestions[iCurrentFact].CheckAnswer(
      rgbEraQuizOptions.Items[rgbEraQuizOptions.ItemIndex]) then
    begin
      Inc(iScore);
      lblEraCorrect.Caption := 'Correct!';
      lblEraCorrect.Font.Color := clGreen;
    end
    else
    begin
      lblEraCorrect.Caption := 'Incorrect!';
      lblEraCorrect.Font.Color := clRed;
    end;

    ShowRandomFact;
  end
  else
  begin
    lblEraCorrect.Caption := 'No era chosen.';
    lblEraCorrect.Font.Color := clRed;
  end;
end;

procedure TfrmHistory_of_Fashion_Quiz.ShowRandomFact;
var
  i : Integer;
  bFound : Boolean;
begin
  bFound := False;

  for i := 1 to iTotalFacts do
    if not arrEraQuestions[i].GetUsed then
    begin
      bFound := True;
      Break;
    end;

  if not bFound then
  begin
    ShowMessage('You have completed the Era Quiz!');

    rTimeLeft := 0;

    Exit;
  end;

  repeat
    iCurrentFact := Random(iTotalFacts) + 1;
  until not arrEraQuestions[iCurrentFact].GetUsed;

  lblEraQuizFact.Caption := arrEraQuestions[iCurrentFact].GetFact;

  arrEraQuestions[iCurrentFact].SetUsed(True);

  rgbEraQuizOptions.ItemIndex := -1;

end;

procedure TfrmHistory_of_Fashion_Quiz.ShowResults;
begin

 lblMainScore.Caption := IntToStr(iScore) + '/10';


   if iScore = 10 then
  begin
    lblMainQuizMessage.Caption :=
      'Fashion Legend!' + sLineBreak +
      'Perfect score!' + sLinebreak + 'You have mastered fashion history!';
  end
  else if iScore >= 8 then
  begin
    lblMainQuizMessage.Caption :=
      'Fashion Scholar' + sLineBreak +
      'Excellent work!' + sLinebreak + 'Your fashion knowledge is impressive.';
  end
  else if iScore >= 6 then
  begin
    lblMainQuizMessage.Caption :=
      'Style Specialist' + sLineBreak +
      'Well done!' + sLinebreak + 'You have a strong understanding of fashion history.';
  end
  else if iScore >= 4 then
  begin
    lblMainQuizMessage.Caption :=
      'Fashion Explorer' + sLineBreak +
      'Good effort!' + sLinebreak + 'Read the fashion facts and see if you can improve.';
  end
  else if iScore >= 2 then
  begin
    lblMainQuizMessage.Caption :=
      'Trend Seeker' + sLineBreak +
      'Nice try!' + sLinebreak + 'Every attempt helps you learn more.';
  end
  else
  begin
    lblMainQuizMessage.Caption :=
      'Fashion Beginner' + sLineBreak +
      'Everyone starts somewhere.' + sLinebreak + 'Explore the fashion facts and try again!';
  end;


 pnlMainQuizQuestions.Hide;
 pnlMainQuizFinalScore.Show;

end;

procedure TfrmHistory_of_Fashion_Quiz.tmrEraQuizTimeTimer(Sender: TObject);
begin
//Every 0.01 seconds: subtract 0.01, update label, and then stop at 0

 rTimeLeft := rTimeLeft - 0.01;
 lblEraQuizTime.Caption := FormatFloat('0.00', rTimeLeft);

  if (rTimeLeft <= 0) AND (PageControl.ActivePage = tabEraQuizGame) then
  begin
    tmrEraQuizTime.Enabled := False;
    lblEraQuizTime.Caption := '0.00';
    ShowMessage('Time is up!');

    pnlEraQuizQuestions.Hide;
    pnlEraQuizFinalScore.Show;

    lblEraQuizFinalScore.Caption := IntToStr(iScore);

    if iScore >= 10 then
     lblEraMessage.Caption := 'Fashion Historian!' + sLineBreak + 'Outstanding!'
    else if iScore >= 8 then
     lblEraMessage.Caption := 'Style Expert!' + sLineBreak + 'Great job!'
    else if iScore >= 6 then
     lblEraMessage.Caption := 'Fashion Enthusiast!' + sLineBreak + 'Well done!'
    else if iScore >= 4 then
     lblEraMessage.Caption := 'Keep Exploring!' + sLineBreak + 'Read the fashion facts and try again.'
    else if iScore >= 2 then
    lblEraMessage.Caption := 'Practice Makes Perfect!' + sLineBreak + 'Try again and improve!'
    else
     lblEraMessage.Caption := 'Ready for a Fashion Journey?' + sLineBreak + 'Browse the facts and give it another go!';

  end;
end;

end.
